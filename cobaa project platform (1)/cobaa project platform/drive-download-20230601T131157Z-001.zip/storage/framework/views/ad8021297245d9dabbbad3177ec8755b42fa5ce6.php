<!--awal BANNER-->
<div class="col-md-12">
    <img src="<?php echo e(asset('gambar')); ?>/bg.jpeg" width="100%" height="280px">
</div>
<!--akhir BANNER--><?php /**PATH C:\praktikum framework\perpus\resources\views/banner.blade.php ENDPATH**/ ?>